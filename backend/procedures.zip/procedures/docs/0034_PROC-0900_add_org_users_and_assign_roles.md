## Procedure

- ID: PROC-0900
- Title: Add org users and assign roles
- Category: ORG
- Audience: Business
- Keywords: org, users, roles
- Triggers: aggiungi utente, assign role, org users
- UI Pages: org-users.html
- API Endpoints: POST /api/org/users, PUT /api/org/users/{id}/role
- Related: -

---

### Objective
Add org users and assign roles

### UI How-to
1. Open org-users.html
2. Add member (email)
3. Assign role
4. Confirm invitation

