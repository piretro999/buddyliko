## Procedure

- ID: PROC-0306
- Title: Execute transformation via API (single file)
- Category: MAPPER
- Audience: Developer
- Keywords: api, execute, transform, file
- Triggers: execute api, api transform
- UI Pages: -
- API Endpoints: POST /api/execute/file, POST /api/transform/execute
- Related: -

---

### Objective
Execute transformation via API (single file)

### API How-to
1. Send Authorization bearer token
2. POST /api/execute/file with mapping reference + file
3. Receive output or download link

### Troubleshooting
- 401/403: check token+role
- 413: use batch

