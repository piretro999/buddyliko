## Procedure

- ID: PROC-2273
- Title: DELETE /api/schema/stored/{stored_id}
- Category: SCHEMA
- Audience: Developer
- Method: DELETE
- Path: /api/schema/stored/{stored_id}
- Keywords: schema, stored, delete
- Triggers: come schema, how to schema, come stored, how to stored, come delete, how to delete
- UI Pages: -
- Source files: api.py, api_prima delle formule dinamiche.py, api_working.py

---

### Objective
Call `DELETE /api/schema/stored/{stored_id}` correctly and interpret the response.

### API How-to
1. Ensure you are authenticated if required (login endpoint or API token).
2. Call the endpoint with correct headers and body (Content-Type: application/json unless uploading files).
3. Check HTTP status code; on non-2xx read error payload and log it.
4. Use the response payload in the next workflow step (e.g., save IDs, update UI, trigger job).

### Security / Governance notes
- Use `Authorization: Bearer <token>` when endpoint requires authentication.
- Log procedure usage with org_id/user_id and response status for audit.

### Screenshot placeholders
- (Optional) If this endpoint is reachable via UI pages listed above, add screenshots under `assets/screenshots/` and reference them from a dedicated UI procedure.
