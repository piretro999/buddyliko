## Procedure

- ID: PROC-1002
- Title: Stripe checkout and customer portal
- Category: BILLING
- Audience: Business
- Keywords: stripe, checkout, portal, subscription
- Triggers: stripe checkout, customer portal, gestisci abbonamento
- UI Pages: account.html, org-billing.html
- API Endpoints: POST /api/billing/checkout, POST /api/billing/portal
- Related: -

---

### Objective
Stripe checkout and customer portal

### UI How-to
1. Open account/billing
2. Click Upgrade or Manage billing
3. Complete Stripe flow
4. Return to Buddyliko and verify plan updated

