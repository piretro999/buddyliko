## Procedure

- ID: PROC-1101
- Title: Purchase and clone template
- Category: MARKETPLACE
- Audience: Business
- Keywords: purchase, clone, template
- Triggers: purchase template, clone template, compra template
- UI Pages: marketplace.html, app.html
- API Endpoints: POST /api/marketplace/purchase, POST /api/marketplace/clone
- Related: -

---

### Objective
Purchase and clone template

### UI How-to
1. Open template
2. Purchase
3. Clone into your workspace
4. Open cloned mapping in app.html

