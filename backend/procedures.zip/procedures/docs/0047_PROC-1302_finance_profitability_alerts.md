## Procedure

- ID: PROC-1302
- Title: Finance: profitability & alerts
- Category: ADMIN_FINANCE
- Audience: Admin
- Keywords: profitability, mrr, arr, alerts, finance
- Triggers: profitability, finance alerts, mrr arr
- UI Pages: finance.html
- API Endpoints: GET /api/finance/profitability, POST /api/finance/alerts
- Related: -

---

### Objective
Finance: profitability & alerts

### UI How-to
1. Open finance.html
2. Review profitability dashboard
3. Configure alerts
4. Save and validate notifications

