## Procedure

- ID: PROC-2343
- Title: GET /auth/facebook/callback
- Category: MISC
- Audience: Developer
- Method: GET
- Path: /auth/facebook/callback
- Keywords: auth, facebook, callback, get
- Triggers: come auth, how to auth, come facebook, how to facebook, come callback, how to callback, come get, how to get
- UI Pages: -
- Source files: api.py, api_prima delle formule dinamiche.py, api_working.py

---

### Objective
Call `GET /auth/facebook/callback` correctly and interpret the response.

### API How-to
1. Ensure you are authenticated if required (login endpoint or API token).
2. Call the endpoint and pass query/path parameters as needed.
3. Check HTTP status code; on non-2xx read error payload and log it.
4. Use the response payload in the next workflow step (e.g., save IDs, update UI, trigger job).

### Security / Governance notes
- Use `Authorization: Bearer <token>` when endpoint requires authentication.
- Log procedure usage with org_id/user_id and response status for audit.

### Screenshot placeholders
- (Optional) If this endpoint is reachable via UI pages listed above, add screenshots under `assets/screenshots/` and reference them from a dedicated UI procedure.
