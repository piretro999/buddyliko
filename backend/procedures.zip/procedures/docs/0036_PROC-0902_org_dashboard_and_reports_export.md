## Procedure

- ID: PROC-0902
- Title: Org dashboard and reports export
- Category: ORG
- Audience: Business
- Keywords: dashboard, reports, export
- Triggers: org dashboard, org reports, export
- UI Pages: org-dashboard.html, org-reports.html
- API Endpoints: GET /api/org/usage, GET /api/org/reports
- Related: -

---

### Objective
Org dashboard and reports export

### UI How-to
1. Open org-dashboard.html to view usage
2. Open org-reports.html to filter analytics
3. Export CSV if available

