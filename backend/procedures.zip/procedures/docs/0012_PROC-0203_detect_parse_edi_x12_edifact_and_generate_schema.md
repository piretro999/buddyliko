## Procedure

- ID: PROC-0203
- Title: Detect/parse EDI (X12/EDIFACT) and generate schema
- Category: SCHEMAS
- Audience: Developer
- Keywords: edi, x12, edifact, detect, parse
- Triggers: edi detect, parse x12, parse edifact
- UI Pages: -
- API Endpoints: POST /api/edi/detect, POST /api/edi/parse, POST /api/edi/schema-from-file, POST /api/edi/build
- Related: -

---

### Objective
Detect/parse EDI (X12/EDIFACT) and generate schema

### API How-to
1. POST /api/edi/detect
2. POST /api/edi/parse
3. POST /api/edi/schema-from-file
4. Use schema in mapping or rebuild via /api/edi/build

