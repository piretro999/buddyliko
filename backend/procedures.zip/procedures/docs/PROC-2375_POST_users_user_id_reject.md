## Procedure

- ID: PROC-2375
- Title: POST /users/{user_id}/reject
- Category: MISC
- Audience: Developer
- Method: POST
- Path: /users/{user_id}/reject
- Keywords: users, reject, post
- Triggers: come users, how to users, come reject, how to reject, come post, how to post
- UI Pages: -
- Source files: admin_api.py

---

### Objective
Call `POST /users/{user_id}/reject` correctly and interpret the response.

### API How-to
1. Ensure you are authenticated if required (login endpoint or API token).
2. Prepare the JSON body as required by the endpoint (use backend code as source of truth).
3. Call the endpoint with correct headers and body (Content-Type: application/json unless uploading files).
4. Check HTTP status code; on non-2xx read error payload and log it.
5. Use the response payload in the next workflow step (e.g., save IDs, update UI, trigger job).

### Security / Governance notes
- Use `Authorization: Bearer <token>` when endpoint requires authentication.
- Log procedure usage with org_id/user_id and response status for audit.

### Screenshot placeholders
- (Optional) If this endpoint is reachable via UI pages listed above, add screenshots under `assets/screenshots/` and reference them from a dedicated UI procedure.
