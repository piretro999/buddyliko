## Procedure

- ID: PROC-2051
- Title: GET /api/batch/stats/overview
- Category: BATCH
- Audience: Developer
- Method: GET
- Path: /api/batch/stats/overview
- Keywords: batch, stats, overview, get
- Triggers: come batch, how to batch, come stats, how to stats, come overview, how to overview, come get, how to get
- UI Pages: help-ai.html
- Source files: batch_api.py

---

### Objective
Call `GET /api/batch/stats/overview` correctly and interpret the response.

### API How-to
1. Ensure you are authenticated if required (login endpoint or API token).
2. Call the endpoint and pass query/path parameters as needed.
3. Check HTTP status code; on non-2xx read error payload and log it.
4. Use the response payload in the next workflow step (e.g., save IDs, update UI, trigger job).

### Security / Governance notes
- Use `Authorization: Bearer <token>` when endpoint requires authentication.
- Log procedure usage with org_id/user_id and response status for audit.

### Screenshot placeholders
- (Optional) If this endpoint is reachable via UI pages listed above, add screenshots under `assets/screenshots/` and reference them from a dedicated UI procedure.
