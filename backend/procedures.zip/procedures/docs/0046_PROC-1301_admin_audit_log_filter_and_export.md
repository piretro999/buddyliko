## Procedure

- ID: PROC-1301
- Title: Admin: audit log filter and export
- Category: ADMIN_FINANCE
- Audience: Admin
- Keywords: audit, log, export
- Triggers: audit log, export audit
- UI Pages: admin.html
- API Endpoints: GET /api/admin/audit, GET /api/admin/audit/export
- Related: -

---

### Objective
Admin: audit log filter and export

### UI How-to
1. Open admin.html
2. Audit Log tab
3. Filter by date/type/user
4. Export CSV

