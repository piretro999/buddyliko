## Procedure

- ID: PROC-0601
- Title: List and filter jobs (status, errors)
- Category: BATCH
- Audience: Developer
- Keywords: jobs, list, errors
- Triggers: jobs list, job errors
- UI Pages: -
- API Endpoints: GET /api/jobs
- Related: -

---

### Objective
List and filter jobs (status, errors)

### API How-to
1. GET /api/jobs
2. Filter by status (running/failed/completed)
3. Open job details to inspect errors

