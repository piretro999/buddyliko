## Procedure

- ID: PROC-2317
- Title: GET /api/webhooks/deliveries/all
- Category: WEBHOOKS
- Audience: Developer
- Method: GET
- Path: /api/webhooks/deliveries/all
- Keywords: webhooks, deliveries, all, get
- Triggers: come webhooks, how to webhooks, come deliveries, how to deliveries, come all, how to all, come get, how to get
- UI Pages: help-ai.html
- Source files: webhook_api.py

---

### Objective
Call `GET /api/webhooks/deliveries/all` correctly and interpret the response.

### API How-to
1. Ensure you are authenticated if required (login endpoint or API token).
2. Call the endpoint and pass query/path parameters as needed.
3. Check HTTP status code; on non-2xx read error payload and log it.
4. Use the response payload in the next workflow step (e.g., save IDs, update UI, trigger job).

### Security / Governance notes
- Use `Authorization: Bearer <token>` when endpoint requires authentication.
- Log procedure usage with org_id/user_id and response status for audit.

### Screenshot placeholders
- (Optional) If this endpoint is reachable via UI pages listed above, add screenshots under `assets/screenshots/` and reference them from a dedicated UI procedure.
