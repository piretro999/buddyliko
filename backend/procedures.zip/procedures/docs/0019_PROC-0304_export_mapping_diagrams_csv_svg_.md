## Procedure

- ID: PROC-0304
- Title: Export mapping & diagrams (CSV/SVG)
- Category: MAPPER
- Audience: Business
- Keywords: export, csv, svg, diagram
- Triggers: export csv, export svg, esporta diagramma
- UI Pages: app.html
- API Endpoints: -
- Related: -

---

### Objective
Export mapping & diagrams (CSV/SVG)

### UI How-to
1. Open mapping
2. Export mapping CSV
3. Export schema CSV
4. Export diagram SVG

