## Procedure

- ID: PROC-0101
- Title: Share Workspace file via expiring link
- Category: WORKSPACE
- Audience: Business
- Keywords: share, link, expiry
- Triggers: condividi link, expiring link, share file
- UI Pages: workspace.html
- API Endpoints: POST /api/workspace/share-link
- Related: -

---

### Objective
Share Workspace file via expiring link

### UI How-to
1. Open workspace.html
2. Select file
3. Share → set expiry
4. Copy link and send

### Security / Governance notes
- Use short expiry for sensitive data

