## Procedure

- ID: PROC-0801
- Title: Verify webhook HMAC-SHA256 signature
- Category: WEBHOOKS
- Audience: Developer
- Keywords: hmac, sha256, signature
- Triggers: verify signature, hmac sha256
- UI Pages: -
- API Endpoints: -
- Related: -

---

### Objective
Verify webhook HMAC-SHA256 signature

### API How-to
1. Compute HMAC-SHA256 on raw request body using shared secret
2. Compare with signature header (constant-time)
3. Reject if mismatch

### Troubleshooting
- Mismatch: ensure raw bytes unchanged and correct secret

