## Procedure

- ID: PROC-1003
- Title: Track AI credit consumption and costs
- Category: BILLING
- Audience: Business
- Keywords: ai, credits, cost
- Triggers: ai credit, ai cost, credit ai
- UI Pages: org-billing.html, finance.html
- API Endpoints: GET /api/finance/ai-credits
- Related: -

---

### Objective
Track AI credit consumption and costs

### UI How-to
1. Open org-billing.html
2. Review AI credit usage chart
3. Use finance.html for global view (admin)

