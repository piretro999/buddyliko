## Procedure

- ID: PROC-2296
- Title: GET /api/standards/domains
- Category: STANDARDS
- Audience: Developer
- Method: GET
- Path: /api/standards/domains
- Keywords: standards, domains, get
- Triggers: come standards, how to standards, come domains, how to domains, come get, how to get
- UI Pages: app.html, help-ai.html, standards-library.html
- Source files: standards_api.py

---

### Objective
Call `GET /api/standards/domains` correctly and interpret the response.

### API How-to
1. Ensure you are authenticated if required (login endpoint or API token).
2. Call the endpoint and pass query/path parameters as needed.
3. Check HTTP status code; on non-2xx read error payload and log it.
4. Use the response payload in the next workflow step (e.g., save IDs, update UI, trigger job).

### Security / Governance notes
- Use `Authorization: Bearer <token>` when endpoint requires authentication.
- Log procedure usage with org_id/user_id and response status for audit.

### Screenshot placeholders
- (Optional) If this endpoint is reachable via UI pages listed above, add screenshots under `assets/screenshots/` and reference them from a dedicated UI procedure.
