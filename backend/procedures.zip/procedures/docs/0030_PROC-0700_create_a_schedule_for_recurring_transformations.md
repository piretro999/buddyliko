## Procedure

- ID: PROC-0700
- Title: Create a schedule for recurring transformations
- Category: SCHEDULING
- Audience: Developer
- Keywords: schedule, cron, recurring
- Triggers: schedule, cron, pianifica
- UI Pages: -
- API Endpoints: POST /api/schedule, GET /api/schedule, POST /api/schedule/{id}/pause, POST /api/schedule/{id}/resume
- Related: -

---

### Objective
Create a schedule for recurring transformations

### API How-to
1. POST /api/schedule (mapping + recurrence)
2. GET /api/schedule
3. Pause/resume as needed
4. Check execution logs

