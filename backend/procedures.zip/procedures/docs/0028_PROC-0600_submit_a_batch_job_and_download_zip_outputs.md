## Procedure

- ID: PROC-0600
- Title: Submit a batch job and download ZIP outputs
- Category: BATCH
- Audience: Developer
- Keywords: batch, zip, jobs
- Triggers: batch job, download zip
- UI Pages: -
- API Endpoints: POST /api/batch/, GET /api/jobs/{id}, GET /api/jobs/{id}/download
- Related: -

---

### Objective
Submit a batch job and download ZIP outputs

### API How-to
1. POST /api/batch/ with mapping + files
2. Poll GET /api/jobs/{id}
3. Download ZIP via /api/jobs/{id}/download

