## Procedure

- ID: PROC-0301
- Title: Edit mapping connections and formulas
- Category: MAPPER
- Audience: Beginner
- Keywords: edit, mapping, formula, connections
- Triggers: modifica mapping, edit mapping
- UI Pages: app.html
- API Endpoints: GET /api/mappings/{id}, PUT /api/mappings/{id}
- Related: -

---

### Objective
Edit mapping connections and formulas

### UI How-to
1. Open mapping list
2. Select mapping
3. Edit connections/formulas
4. Save changes

