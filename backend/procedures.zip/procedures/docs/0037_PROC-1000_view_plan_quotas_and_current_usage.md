## Procedure

- ID: PROC-1000
- Title: View plan, quotas, and current usage
- Category: BILLING
- Audience: Business
- Keywords: plan, quota, usage
- Triggers: piano, quota, usage
- UI Pages: account.html, org-billing.html
- API Endpoints: GET /api/billing/status, GET /api/billing/usage
- Related: -

---

### Objective
View plan, quotas, and current usage

### UI How-to
1. Open account.html
2. Open org-billing.html
3. Review transforms remaining and AI credits (if applicable)

