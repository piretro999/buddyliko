## Procedure

- ID: PROC-2370
- Title: GET /unread-count
- Category: MISC
- Audience: Developer
- Method: GET
- Path: /unread-count
- Keywords: unread-count, get
- Triggers: come unread-count, how to unread-count, come get, how to get
- UI Pages: -
- Source files: notifications.py

---

### Objective
Call `GET /unread-count` correctly and interpret the response.

### API How-to
1. Ensure you are authenticated if required (login endpoint or API token).
2. Call the endpoint and pass query/path parameters as needed.
3. Check HTTP status code; on non-2xx read error payload and log it.
4. Use the response payload in the next workflow step (e.g., save IDs, update UI, trigger job).

### Security / Governance notes
- Use `Authorization: Bearer <token>` when endpoint requires authentication.
- Log procedure usage with org_id/user_id and response status for audit.

### Screenshot placeholders
- (Optional) If this endpoint is reachable via UI pages listed above, add screenshots under `assets/screenshots/` and reference them from a dedicated UI procedure.
