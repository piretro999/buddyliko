## Procedure

- ID: PROC-2336
- Title: DELETE /api/workspace/files/{file_id}/share/{link_id}
- Category: WORKSPACE
- Audience: Developer
- Method: DELETE
- Path: /api/workspace/files/{file_id}/share/{link_id}
- Keywords: workspace, files, share, delete
- Triggers: come workspace, how to workspace, come files, how to files, come share, how to share, come delete, how to delete
- UI Pages: -
- Source files: groups_api.py

---

### Objective
Call `DELETE /api/workspace/files/{file_id}/share/{link_id}` correctly and interpret the response.

### API How-to
1. Ensure you are authenticated if required (login endpoint or API token).
2. Call the endpoint with correct headers and body (Content-Type: application/json unless uploading files).
3. Check HTTP status code; on non-2xx read error payload and log it.
4. Use the response payload in the next workflow step (e.g., save IDs, update UI, trigger job).

### Security / Governance notes
- Use `Authorization: Bearer <token>` when endpoint requires authentication.
- Log procedure usage with org_id/user_id and response status for audit.

### Screenshot placeholders
- (Optional) If this endpoint is reachable via UI pages listed above, add screenshots under `assets/screenshots/` and reference them from a dedicated UI procedure.
