## Procedure

- ID: PROC-2231
- Title: POST /api/partnership/sub-orgs/{sub_org_id}/clone-settings
- Category: PARTNERSHIP
- Audience: Developer
- Method: POST
- Path: /api/partnership/sub-orgs/{sub_org_id}/clone-settings
- Keywords: partnership, sub-orgs, clone-settings, post
- Triggers: come partnership, how to partnership, come sub-orgs, how to sub-orgs, come clone-settings, how to clone-settings, come post, how to post
- UI Pages: -
- Source files: partnership_api.py

---

### Objective
Call `POST /api/partnership/sub-orgs/{sub_org_id}/clone-settings` correctly and interpret the response.

### API How-to
1. Ensure you are authenticated if required (login endpoint or API token).
2. Prepare the JSON body as required by the endpoint (use backend code as source of truth).
3. Call the endpoint with correct headers and body (Content-Type: application/json unless uploading files).
4. Check HTTP status code; on non-2xx read error payload and log it.
5. Use the response payload in the next workflow step (e.g., save IDs, update UI, trigger job).

### Security / Governance notes
- Use `Authorization: Bearer <token>` when endpoint requires authentication.
- Log procedure usage with org_id/user_id and response status for audit.

### Screenshot placeholders
- (Optional) If this endpoint is reachable via UI pages listed above, add screenshots under `assets/screenshots/` and reference them from a dedicated UI procedure.
