## Procedure

- ID: PROC-0300
- Title: Create a new mapping (drag & drop) and execute
- Category: MAPPER
- Audience: Beginner
- Keywords: mapping, drag, drop, connect, execute
- Triggers: crea mapping, drag and drop, nuova mappa
- UI Pages: app.html
- API Endpoints: POST /api/mappings, POST /api/execute/file, GET /api/mappings/list
- Related: -

---

### Objective
Create a new mapping (drag & drop) and execute

### UI How-to
1. Open app.html
2. Upload input schema (left)
3. Upload output schema (right)
4. Drag/connect fields
5. Click a connection to set formula
6. Save mapping
7. Execute transform with a sample input
8. Download output

### Advanced options
- AI AutoMap
- Export mapping/schema CSV
- Export diagram SVG
- Generate code

