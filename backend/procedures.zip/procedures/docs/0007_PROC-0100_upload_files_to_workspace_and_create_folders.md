## Procedure

- ID: PROC-0100
- Title: Upload files to Workspace and create folders
- Category: WORKSPACE
- Audience: Beginner
- Keywords: workspace, upload, folder, file
- Triggers: workspace upload, carica file, cartella
- UI Pages: workspace.html
- API Endpoints: POST /api/workspace/upload, POST /api/workspace/folders, GET /api/workspace/list
- Related: -

---

### Objective
Upload files to Workspace and create folders

### UI How-to
1. Open workspace.html
2. Upload files
3. Create folder
4. Move files into folder
5. Use search to find files

### Troubleshooting
- Upload fails: check size limits or network

