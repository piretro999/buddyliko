## Procedure

- ID: PROC-1402
- Title: Deployment: reverse proxy + HTTPS + SSE/WebSockets
- Category: DEPLOYMENT
- Audience: Developer
- Keywords: reverse proxy, https, nginx, sse, websocket
- Triggers: nginx, reverse proxy, https, sse
- UI Pages: -
- API Endpoints: -
- Related: -

---

### Objective
Deployment: reverse proxy + HTTPS + SSE/WebSockets

### API How-to
1. Serve app.html and /api under same origin if possible
2. Proxy /api/ai/auto-map-stream with proper buffering disabled for SSE
3. Set X-Forwarded-Proto/Host
4. Enable gzip carefully for SSE

