## Procedure

- ID: PROC-2100
- Title: POST /api/dbconn/{conn_id}/test
- Category: DBCONN
- Audience: Developer
- Method: POST
- Path: /api/dbconn/{conn_id}/test
- Keywords: dbconn, test, post
- Triggers: come dbconn, how to dbconn, come test, how to test, come post, how to post
- UI Pages: -
- Source files: api.py, api_working.py

---

### Objective
Call `POST /api/dbconn/{conn_id}/test` correctly and interpret the response.

### API How-to
1. Ensure you are authenticated if required (login endpoint or API token).
2. Prepare the JSON body as required by the endpoint (use backend code as source of truth).
3. Call the endpoint with correct headers and body (Content-Type: application/json unless uploading files).
4. Check HTTP status code; on non-2xx read error payload and log it.
5. Use the response payload in the next workflow step (e.g., save IDs, update UI, trigger job).

### Security / Governance notes
- Use `Authorization: Bearer <token>` when endpoint requires authentication.
- Log procedure usage with org_id/user_id and response status for audit.

### Screenshot placeholders
- (Optional) If this endpoint is reachable via UI pages listed above, add screenshots under `assets/screenshots/` and reference them from a dedicated UI procedure.
