## Procedure

- ID: PROC-1102
- Title: Publish mapping to Marketplace
- Category: MARKETPLACE
- Audience: Business
- Keywords: publish, sell, template
- Triggers: publish marketplace, pubblica template
- UI Pages: app.html, marketplace.html
- API Endpoints: POST /api/marketplace/publish
- Related: -

---

### Objective
Publish mapping to Marketplace

### UI How-to
1. Open mapping
2. Publish
3. Set price/metadata
4. Confirm
5. Verify listing

