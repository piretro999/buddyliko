## Procedure

- ID: PROC-0002
- Title: Log in (email/password)
- Category: AUTH
- Audience: Beginner
- Keywords: login, sign in, token, session
- Triggers: login, accedi, sign in
- UI Pages: login.html
- API Endpoints: POST /api/auth/login, GET /api/auth/me
- Related: -

---

### Objective
Log in (email/password)

### UI How-to
1. Open login.html
2. Enter email/password
3. Click Login
4. Complete MFA if prompted
5. Confirm you reach topbar pages

### API How-to
1. POST /api/auth/login
2. Store JWT
3. Use Authorization: Bearer <token>

### Troubleshooting
- 401: wrong credentials or blocked
- Redirect loop: token not stored

