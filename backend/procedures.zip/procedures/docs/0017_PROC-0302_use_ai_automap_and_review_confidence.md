## Procedure

- ID: PROC-0302
- Title: Use AI AutoMap and review confidence
- Category: MAPPER
- Audience: Business
- Keywords: ai, automap, confidence
- Triggers: ai automap, auto-map
- UI Pages: app.html
- API Endpoints: POST /api/ai/auto-map, POST /api/ai/auto-map-stream
- Related: -

---

### Objective
Use AI AutoMap and review confidence

### UI How-to
1. Load input/output schemas
2. Click AI AutoMap
3. Review suggestions and confidence
4. Accept/reject links
5. Save mapping

### Security / Governance notes
- Always review before saving in enterprise contexts

