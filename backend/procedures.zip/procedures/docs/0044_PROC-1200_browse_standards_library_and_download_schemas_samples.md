## Procedure

- ID: PROC-1200
- Title: Browse Standards Library and download schemas/samples
- Category: STANDARDS
- Audience: Business
- Keywords: standards, library, download, schema, samples
- Triggers: standards library, download schema, libreria standard
- UI Pages: standards-library.html
- API Endpoints: GET /api/standards, GET /api/standards/{id}/download
- Related: -

---

### Objective
Browse Standards Library and download schemas/samples

### UI How-to
1. Open standards-library.html
2. Search a standard
3. Open details
4. Download schema/sample files

