## Procedure

- ID: PROC-0305
- Title: Generate code from mapping (offline runner)
- Category: MAPPER
- Audience: Developer
- Keywords: code, generate, python, java, xslt, node
- Triggers: genera codice, generate code
- UI Pages: app.html
- API Endpoints: -
- Related: -

---

### Objective
Generate code from mapping (offline runner)

### UI How-to
1. Open mapping
2. Generate Code
3. Choose language
4. Download package
5. Run locally with sample input

