## Procedure

- ID: PROC-0401
- Title: Validate XML with Schematron
- Category: VALIDATION
- Audience: Developer
- Keywords: schematron, validate
- Triggers: validazione schematron, schematron validation
- UI Pages: -
- API Endpoints: POST /api/xml/schematron/validate, POST /api/execute
- Related: -

---

### Objective
Validate XML with Schematron

### API How-to
1. POST /api/xml/schematron/validate with xml+schematron
2. Review failed assertions
3. Fix and retry

