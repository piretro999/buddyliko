## Procedure

- ID: PROC-0802
- Title: Webhook delivery logs and retries
- Category: WEBHOOKS
- Audience: Business
- Keywords: delivery, retries, logs
- Triggers: delivery logs, webhook retry
- UI Pages: org-reports.html, admin.html
- API Endpoints: GET /api/webhooks/deliveries
- Related: -

---

### Objective
Webhook delivery logs and retries

### UI How-to
1. Open reports/audit area
2. Filter webhook deliveries
3. Inspect attempts and last error

