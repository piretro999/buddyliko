## Procedure

- ID: PROC-0402
- Title: Validate JSON with JSON Schema
- Category: VALIDATION
- Audience: Developer
- Keywords: json, validate, jsonschema
- Triggers: validazione json schema, jsonschema validation
- UI Pages: -
- API Endpoints: POST /api/json/validate
- Related: -

---

### Objective
Validate JSON with JSON Schema

### API How-to
1. POST /api/json/validate with json+schema
2. Review errors
3. Fix and retry

