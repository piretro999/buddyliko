## Procedure

- ID: PROC-0201
- Title: Infer schema from sample XML/JSON/CSV (schema-from-file)
- Category: SCHEMAS
- Audience: Developer
- Keywords: infer, schema, sample, from file
- Triggers: schema from sample, infer schema
- UI Pages: -
- API Endpoints: POST /api/schema/from-sample
- Related: -

---

### Objective
Infer schema from sample XML/JSON/CSV (schema-from-file)

### API How-to
1. POST /api/schema/from-sample with sample file
2. Use returned schema in the Mapper

