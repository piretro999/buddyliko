## Procedure

- ID: PROC-1401
- Title: Troubleshoot: 401/redirect loop due to JWT token
- Category: TROUBLESHOOT
- Audience: Developer
- Keywords: 401, jwt, token, redirect
- Triggers: 401, redirect login, token
- UI Pages: -
- API Endpoints: -
- Related: -

---

### Objective
Troubleshoot: 401/redirect loop due to JWT token

### UI How-to
1. Check localStorage token key
2. Logout/login again
3. Confirm Authorization header in requests

### Troubleshooting
- Clock skew can invalidate tokens; check server time

