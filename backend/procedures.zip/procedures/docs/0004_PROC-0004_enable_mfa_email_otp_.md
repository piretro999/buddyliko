## Procedure

- ID: PROC-0004
- Title: Enable MFA (Email OTP)
- Category: AUTH
- Audience: Beginner
- Keywords: mfa, email, otp
- Triggers: mfa email, email otp
- UI Pages: account-settings.html
- API Endpoints: POST /api/auth/mfa/email/*
- Related: -

---

### Objective
Enable MFA (Email OTP)

### UI How-to
1. Open account-settings.html
2. MFA → Email
3. Enable
4. Enter OTP received
5. Confirm

### Troubleshooting
- No OTP: check spam; verify mailbox

