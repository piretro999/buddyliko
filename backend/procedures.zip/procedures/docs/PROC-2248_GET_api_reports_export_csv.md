## Procedure

- ID: PROC-2248
- Title: GET /api/reports/export/csv
- Category: REPORTS
- Audience: Developer
- Method: GET
- Path: /api/reports/export/csv
- Keywords: reports, export, csv, get
- Triggers: come reports, how to reports, come export, how to export, come csv, how to csv, come get, how to get
- UI Pages: -
- Source files: report_api.py

---

### Objective
Call `GET /api/reports/export/csv` correctly and interpret the response.

### API How-to
1. Ensure you are authenticated if required (login endpoint or API token).
2. Call the endpoint and pass query/path parameters as needed.
3. Check HTTP status code; on non-2xx read error payload and log it.
4. Use the response payload in the next workflow step (e.g., save IDs, update UI, trigger job).

### Security / Governance notes
- Use `Authorization: Bearer <token>` when endpoint requires authentication.
- Log procedure usage with org_id/user_id and response status for audit.

### Screenshot placeholders
- (Optional) If this endpoint is reachable via UI pages listed above, add screenshots under `assets/screenshots/` and reference them from a dedicated UI procedure.
