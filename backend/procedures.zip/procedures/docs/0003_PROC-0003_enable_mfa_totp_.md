## Procedure

- ID: PROC-0003
- Title: Enable MFA (TOTP)
- Category: AUTH
- Audience: Beginner
- Keywords: mfa, totp, 2fa, authenticator
- Triggers: abilita mfa, enable mfa, totp
- UI Pages: account-settings.html
- API Endpoints: POST /api/auth/mfa/totp/*
- Related: -

---

### Objective
Enable MFA (TOTP)

### UI How-to
1. Open account-settings.html
2. MFA → Authenticator (TOTP)
3. Scan QR
4. Enter code to confirm
5. Save and test logout/login

### Troubleshooting
- Codes mismatch: enable device time sync

