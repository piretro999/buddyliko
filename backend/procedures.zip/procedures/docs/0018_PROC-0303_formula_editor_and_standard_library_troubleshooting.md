## Procedure

- ID: PROC-0303
- Title: Formula Editor and standard library troubleshooting
- Category: MAPPER
- Audience: Developer
- Keywords: formula, library, components, load
- Triggers: formula library, componenti formula
- UI Pages: app.html
- API Endpoints: GET /api/formulas
- Related: -

---

### Objective
Formula Editor and standard library troubleshooting

### UI How-to
1. Click connection line
2. Open formula picker
3. Search formula
4. Configure parameters
5. Save and preview

### Troubleshooting
- If components missing: check /api/formulas response and static assets paths

