## Procedure

- ID: PROC-1300
- Title: Admin: manage users globally
- Category: ADMIN_FINANCE
- Audience: Admin
- Keywords: admin, users, roles, block
- Triggers: admin users, block user, override role
- UI Pages: admin.html
- API Endpoints: GET /api/admin/users, PUT /api/admin/users/{id}/role, PUT /api/admin/users/{id}/status
- Related: -

---

### Objective
Admin: manage users globally

### UI How-to
1. Open admin.html
2. Users tab
3. Search user
4. Change role/status
5. Save

