## Procedure

- ID: PROC-0502
- Title: Write transformation output to DB
- Category: DB
- Audience: Developer
- Keywords: write, db, insert, update
- Triggers: write to db, db write
- UI Pages: -
- API Endpoints: POST /api/dbconn/{id}/execute-write
- Related: -

---

### Objective
Write transformation output to DB

### API How-to
1. Prepare mapping output target as DB table
2. POST /api/dbconn/{id}/execute-write
3. Verify rows in DB

