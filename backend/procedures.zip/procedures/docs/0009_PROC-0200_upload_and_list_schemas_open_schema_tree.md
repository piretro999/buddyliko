## Procedure

- ID: PROC-0200
- Title: Upload and list schemas; open schema tree
- Category: SCHEMAS
- Audience: Beginner
- Keywords: schema, upload, list, tree
- Triggers: carica schema, schema list, schema tree
- UI Pages: app.html
- API Endpoints: POST /api/schemas/upload, GET /api/schemas/list, GET /api/schemas/{schema_id}/tree
- Related: -

---

### Objective
Upload and list schemas; open schema tree

### UI How-to
1. In app.html → Upload input/output schema
2. Use schema list to reuse existing schemas
3. Open schema tree to browse nested elements

### API How-to
1. POST /api/schemas/upload
2. GET /api/schemas/list
3. GET /api/schemas/{id}/tree

