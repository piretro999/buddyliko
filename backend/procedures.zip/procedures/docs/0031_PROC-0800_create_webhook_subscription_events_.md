## Procedure

- ID: PROC-0800
- Title: Create webhook subscription (events)
- Category: WEBHOOKS
- Audience: Developer
- Keywords: webhook, subscribe, events
- Triggers: create webhook, configura webhook
- UI Pages: org-settings.html
- API Endpoints: POST /api/webhooks, GET /api/webhooks, DELETE /api/webhooks/{id}
- Related: -

---

### Objective
Create webhook subscription (events)

### UI How-to
1. Open org-settings.html
2. Webhooks → Add
3. Set URL + events
4. Save
5. Trigger an event and verify delivery log

