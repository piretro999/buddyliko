## Procedure

- ID: PROC-0204
- Title: Detect/parse HL7 and generate schema
- Category: SCHEMAS
- Audience: Developer
- Keywords: hl7, detect, parse, schema
- Triggers: hl7 detect, hl7 parse
- UI Pages: -
- API Endpoints: POST /api/hl7/detect, POST /api/hl7/parse, POST /api/hl7/schema-from-file, POST /api/hl7/build-v2
- Related: -

---

### Objective
Detect/parse HL7 and generate schema

### API How-to
1. POST /api/hl7/detect
2. POST /api/hl7/parse
3. POST /api/hl7/schema-from-file
4. Build HL7 via /api/hl7/build-v2

