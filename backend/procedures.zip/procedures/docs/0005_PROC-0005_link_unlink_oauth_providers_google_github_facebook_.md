## Procedure

- ID: PROC-0005
- Title: Link/Unlink OAuth providers (Google/GitHub/Facebook)
- Category: ACCOUNT
- Audience: Beginner
- Keywords: oauth, google, github, facebook, link, unlink
- Triggers: collega google, link github, link facebook, unlink
- UI Pages: account-settings.html
- API Endpoints: POST /api/auth/oauth/*
- Related: -

---

### Objective
Link/Unlink OAuth providers (Google/GitHub/Facebook)

### UI How-to
1. Open account-settings.html
2. Linked methods → Link provider
3. Complete consent
4. Verify linked
5. Unlink if needed (keep at least one method)

### Troubleshooting
- Provider redirect error: wrong callback URL

