## Procedure

- ID: PROC-2000
- Title: GET /
- Category: MISC
- Audience: Developer
- Method: GET
- Path: /
- Keywords: get
- Triggers: come get, how to get
- UI Pages: SchemaManagement.jsx, SchemaSelector.jsx, SchemaUpload.jsx, admin_working.html, app.html, app_faccione.html, app_working.html, help-ai.html, index.html, login.html, standards-library.html
- Source files: api.py, api_prima delle formule dinamiche.py, api_working.py, main_complete.py, notifications.py

---

### Objective
Call `GET /` correctly and interpret the response.

### API How-to
1. Ensure you are authenticated if required (login endpoint or API token).
2. Call the endpoint and pass query/path parameters as needed.
3. Check HTTP status code; on non-2xx read error payload and log it.
4. Use the response payload in the next workflow step (e.g., save IDs, update UI, trigger job).

### Security / Governance notes
- Use `Authorization: Bearer <token>` when endpoint requires authentication.
- Log procedure usage with org_id/user_id and response status for audit.

### Screenshot placeholders
- (Optional) If this endpoint is reachable via UI pages listed above, add screenshots under `assets/screenshots/` and reference them from a dedicated UI procedure.
