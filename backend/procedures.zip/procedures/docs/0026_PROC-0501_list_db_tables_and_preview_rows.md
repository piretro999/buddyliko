## Procedure

- ID: PROC-0501
- Title: List DB tables and preview rows
- Category: DB
- Audience: Developer
- Keywords: tables, preview, schema
- Triggers: list tables, preview rows
- UI Pages: -
- API Endpoints: GET /api/dbconn/{id}/tables, POST /api/dbconn/{id}/preview, POST /api/dbconn/{id}/schema
- Related: -

---

### Objective
List DB tables and preview rows

### API How-to
1. GET /api/dbconn/{id}/tables
2. POST /api/dbconn/{id}/preview
3. POST /api/dbconn/{id}/schema

