## Procedure

- ID: PROC-0400
- Title: Validate XML with XSD
- Category: VALIDATION
- Audience: Developer
- Keywords: xsd, validate, xml
- Triggers: validazione xsd, xsd validation
- UI Pages: -
- API Endpoints: POST /api/xml/validate, POST /api/execute
- Related: -

---

### Objective
Validate XML with XSD

### API How-to
1. POST /api/xml/validate with xml+xsd
2. Review errors and line/column
3. Fix mapping or data and retry

