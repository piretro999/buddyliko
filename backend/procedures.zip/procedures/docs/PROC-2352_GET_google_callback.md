## Procedure

- ID: PROC-2352
- Title: GET /google/callback
- Category: MISC
- Audience: Developer
- Method: GET
- Path: /google/callback
- Keywords: google, callback, get
- Triggers: come google, how to google, come callback, how to callback, come get, how to get
- UI Pages: -
- Source files: auth.py

---

### Objective
Call `GET /google/callback` correctly and interpret the response.

### API How-to
1. Ensure you are authenticated if required (login endpoint or API token).
2. Call the endpoint and pass query/path parameters as needed.
3. Check HTTP status code; on non-2xx read error payload and log it.
4. Use the response payload in the next workflow step (e.g., save IDs, update UI, trigger job).

### Security / Governance notes
- Use `Authorization: Bearer <token>` when endpoint requires authentication.
- Log procedure usage with org_id/user_id and response status for audit.

### Screenshot placeholders
- (Optional) If this endpoint is reachable via UI pages listed above, add screenshots under `assets/screenshots/` and reference them from a dedicated UI procedure.
