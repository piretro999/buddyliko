## Procedure

- ID: PROC-0205
- Title: Parse SAP IDoc and generate definition schema
- Category: SCHEMAS
- Audience: Developer
- Keywords: idoc, sap, parse, definition
- Triggers: idoc parse, sap idoc
- UI Pages: -
- API Endpoints: POST /api/idoc/parse, POST /api/idoc/definition-from-file
- Related: -

---

### Objective
Parse SAP IDoc and generate definition schema

### API How-to
1. POST /api/idoc/parse
2. POST /api/idoc/definition-from-file
3. Load definition in mapper

