## Procedure

- ID: PROC-2033
- Title: GET /api/auth/me
- Category: AUTH
- Audience: Developer
- Method: GET
- Path: /api/auth/me
- Keywords: auth, me, get
- Triggers: come auth, how to auth, come me, how to me, come get, how to get
- UI Pages: app.html, app_faccione.html, app_working.html, login.html
- Source files: api.py, api_prima delle formule dinamiche.py, api_working.py

---

### Objective
Call `GET /api/auth/me` correctly and interpret the response.

### API How-to
1. Ensure you are authenticated if required (login endpoint or API token).
2. Call the endpoint and pass query/path parameters as needed.
3. Check HTTP status code; on non-2xx read error payload and log it.
4. Use the response payload in the next workflow step (e.g., save IDs, update UI, trigger job).

### Security / Governance notes
- Use `Authorization: Bearer <token>` when endpoint requires authentication.
- Log procedure usage with org_id/user_id and response status for audit.

### Screenshot placeholders
- (Optional) If this endpoint is reachable via UI pages listed above, add screenshots under `assets/screenshots/` and reference them from a dedicated UI procedure.
