## Procedure

- ID: PROC-0500
- Title: Create and test a DB connector
- Category: DB
- Audience: Developer
- Keywords: db, connector, test, save
- Triggers: db connector, test db, connessione db
- UI Pages: -
- API Endpoints: POST /api/dbconn/save, POST /api/dbconn/test, GET /api/dbconn/list
- Related: -

---

### Objective
Create and test a DB connector

### API How-to
1. POST /api/dbconn/save
2. POST /api/dbconn/test
3. GET /api/dbconn/list

