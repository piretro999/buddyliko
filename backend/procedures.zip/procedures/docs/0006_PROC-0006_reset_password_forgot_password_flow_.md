## Procedure

- ID: PROC-0006
- Title: Reset password (forgot password flow)
- Category: ACCOUNT
- Audience: Beginner
- Keywords: forgot, reset, password
- Triggers: password dimenticata, forgot password, reset password
- UI Pages: login.html
- API Endpoints: POST /api/auth/password-reset/request, POST /api/auth/password-reset/confirm
- Related: -

---

### Objective
Reset password (forgot password flow)

### UI How-to
1. Open login.html
2. Click Forgot Password
3. Enter email
4. Use link/code from email
5. Set new password
6. Login

### Troubleshooting
- Expired link: request again

