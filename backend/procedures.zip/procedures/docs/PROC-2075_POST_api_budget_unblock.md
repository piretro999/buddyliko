## Procedure

- ID: PROC-2075
- Title: POST /api/budget/unblock
- Category: BUDGET
- Audience: Developer
- Method: POST
- Path: /api/budget/unblock
- Keywords: budget, unblock, post
- Triggers: come budget, how to budget, come unblock, how to unblock, come post, how to post
- UI Pages: help-ai.html
- Source files: budget_api.py

---

### Objective
Call `POST /api/budget/unblock` correctly and interpret the response.

### API How-to
1. Ensure you are authenticated if required (login endpoint or API token).
2. Prepare the JSON body as required by the endpoint (use backend code as source of truth).
3. Call the endpoint with correct headers and body (Content-Type: application/json unless uploading files).
4. Check HTTP status code; on non-2xx read error payload and log it.
5. Use the response payload in the next workflow step (e.g., save IDs, update UI, trigger job).

### Security / Governance notes
- Use `Authorization: Bearer <token>` when endpoint requires authentication.
- Log procedure usage with org_id/user_id and response status for audit.

### Screenshot placeholders
- (Optional) If this endpoint is reachable via UI pages listed above, add screenshots under `assets/screenshots/` and reference them from a dedicated UI procedure.
