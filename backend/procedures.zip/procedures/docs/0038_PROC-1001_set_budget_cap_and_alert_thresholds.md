## Procedure

- ID: PROC-1001
- Title: Set budget cap and alert thresholds
- Category: BILLING
- Audience: Business
- Keywords: budget, cap, alerts, threshold
- Triggers: budget cap, alert budget, limite spesa
- UI Pages: org-billing.html
- API Endpoints: POST /api/billing/budget-cap, GET /api/billing/budget-cap
- Related: -

---

### Objective
Set budget cap and alert thresholds

### UI How-to
1. Open org-billing.html
2. Set monthly cap
3. Enable threshold alerts
4. Save
5. Verify auto-block behavior at 100%

### Security / Governance notes
- Restrict to Finance/Admin roles

