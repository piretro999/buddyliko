## Procedure

- ID: PROC-1400
- Title: Troubleshoot: app.html components/assets not loading
- Category: TROUBLESHOOT
- Audience: Developer
- Keywords: static, assets, components, 404, app.html
- Triggers: assets 404, componenti non caricano, link non funzionano
- UI Pages: app.html
- API Endpoints: -
- Related: -

---

### Objective
Troubleshoot: app.html components/assets not loading

### UI How-to
1. Open DevTools → Network
2. Reload page
3. Identify 404 assets
4. Fix StaticFiles mount paths and base URL
5. Hard-reload to clear cache

### Troubleshooting
- If reverse proxy: ensure correct root path and forwarded headers

