## Procedure

- ID: PROC-0901
- Title: Manage trading partners; CSV import
- Category: ORG
- Audience: Business
- Keywords: partners, import, csv
- Triggers: trading partners, import partners, partner csv
- UI Pages: org-partners.html
- API Endpoints: POST /api/org/partners, POST /api/org/partners/import
- Related: -

---

### Objective
Manage trading partners; CSV import

### UI How-to
1. Open org-partners.html
2. Add partner manually OR import CSV
3. Validate list

### Troubleshooting
- Import fails: check CSV headers

