## Procedure

- ID: PROC-0001
- Title: Register a new account (email/password)
- Category: AUTH
- Audience: Beginner
- Keywords: register, signup, account, email, password
- Triggers: registrati, crea account, sign up, register
- UI Pages: login.html
- API Endpoints: POST /api/auth/register
- Related: -
- Preconditions: No active session

---

### Objective
Register a new account (email/password)

### UI How-to
1. Open login.html
2. Click 'Register'
3. Enter email + password
4. Confirm
5. If required, verify email
6. Log in

### API How-to
1. POST /api/auth/register (email,password)
2. If token returned, store it; else login normally
3. GET /api/auth/me to confirm session

### Troubleshooting
- If password rejected: follow password policy
- If verification email missing: check spam

