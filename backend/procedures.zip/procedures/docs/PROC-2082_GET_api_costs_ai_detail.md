## Procedure

- ID: PROC-2082
- Title: GET /api/costs/ai-detail
- Category: COSTS
- Audience: Developer
- Method: GET
- Path: /api/costs/ai-detail
- Keywords: costs, ai-detail, get
- Triggers: come costs, how to costs, come ai-detail, how to ai-detail, come get, how to get
- UI Pages: -
- Source files: cost_api.py

---

### Objective
Call `GET /api/costs/ai-detail` correctly and interpret the response.

### API How-to
1. Ensure you are authenticated if required (login endpoint or API token).
2. Call the endpoint and pass query/path parameters as needed.
3. Check HTTP status code; on non-2xx read error payload and log it.
4. Use the response payload in the next workflow step (e.g., save IDs, update UI, trigger job).

### Security / Governance notes
- Use `Authorization: Bearer <token>` when endpoint requires authentication.
- Log procedure usage with org_id/user_id and response status for audit.

### Screenshot placeholders
- (Optional) If this endpoint is reachable via UI pages listed above, add screenshots under `assets/screenshots/` and reference them from a dedicated UI procedure.
