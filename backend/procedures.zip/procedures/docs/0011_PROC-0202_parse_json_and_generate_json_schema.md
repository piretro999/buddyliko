## Procedure

- ID: PROC-0202
- Title: Parse JSON and generate JSON Schema
- Category: SCHEMAS
- Audience: Developer
- Keywords: json, parse, json schema
- Triggers: json parse, json schema
- UI Pages: -
- API Endpoints: POST /api/json/parse, POST /api/json/schema-from-file
- Related: -

---

### Objective
Parse JSON and generate JSON Schema

### API How-to
1. POST /api/json/parse for normalized structure
2. POST /api/json/schema-from-file to generate schema
3. Load schema in mapper

